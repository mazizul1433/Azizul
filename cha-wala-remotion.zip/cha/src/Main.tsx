import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {fr, clamp} from './theme';
import {TOTAL, S} from './timeline';
import {TProvider, useT, Caption} from './ui';
import {DLG} from './captions';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';

// স্ক্রিন শেক + ফেড-ইন; ঝাঁকুনি হলে ১.০২ জুম যাতে কিনারায় ফাঁক না থাকে (ফুল-স্ক্রিন)
const Frame: React.FC<{shake?: [number, number]; children: React.ReactNode}> = ({shake, children}) => {
  const t = useT(), f = useCurrentFrame();
  const on = !!shake && t >= shake[0] && t < shake[1];
  const sx = on ? Math.sin(f * 2.9) * 8 : 0, sy = on ? Math.cos(f * 3.7) * 6 : 0;
  return <AbsoluteFill style={{transform: `translate(${sx}px,${sy}px) scale(${on ? 1.02 : 1})`, opacity: clamp(f / 8)}}>{children}</AbsoluteFill>;
};

const items: [readonly [number, number], React.FC, [number, number]?][] = [
  [S.s1, Scene1],
  [S.s2, Scene2, [DLG[1][0] + 0.2, DLG[1][0] + 0.5]],
  [S.s3, Scene3, [DLG[2][0], DLG[2][1]]],
  [S.s4, Scene4],
  [S.s5, Scene5],
  [S.s6, Scene6],
];

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    <Audio src={staticFile('voice.wav')} />
    {items.map(([r, C, shake], i) => {
      const from = fr(r[0]), end = i === items.length - 1 ? TOTAL : fr(r[1]);
      return (
        <Sequence key={i} from={from} durationInFrames={end - from}>
          <TProvider value={r[0]}><Frame shake={shake}><C /></Frame></TProvider>
        </Sequence>
      );
    })}
    <Caption />
  </AbsoluteFill>
);
