import React from 'react';
import {W, H, INK, FONT} from './theme';

const Full: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
);
const Stripes = () => (
  <pattern id="st" width="60" height="80" patternUnits="userSpaceOnUse">
    <rect width="30" height="80" fill="#e25b5b" /><rect x="30" width="30" height="80" fill="#fff" />
  </pattern>
);
const o = {stroke: INK, strokeWidth: 2.5, strokeLinejoin: 'round' as const};
const Txt: React.FC<{x: number; y: number; size: number; fill?: string; children: React.ReactNode}> = ({x, y, size, fill = INK, children}) => (
  <text x={x} y={y} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={fill} stroke="none">{children}</text>
);
const Ground: React.FC = () => (
  <>
    <rect y={1260} width={W} height={70} fill="#d8d2c4" {...o} />
    <rect y={1330} width={W} height={H - 1330} fill="#7b7f87" />
    {[0, 1, 2, 3, 4, 5].map(i => <rect key={i} x={i * 200 + 40} y={1640} width={120} height={14} rx={6} fill="#f5f5f5" />)}
  </>
);

export const BazaarBG: React.FC<{dawn?: boolean}> = ({dawn}) => (
  <Full>
    <defs>
      <linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={dawn ? '#ffcf9f' : '#9fd6f7'} /><stop offset="1" stopColor={dawn ? '#fff1d6' : '#e6f6ff'} /></linearGradient>
      <Stripes />
    </defs>
    <rect width={W} height={H} fill="url(#sk)" />
    <circle cx={dawn ? 200 : 880} cy={dawn ? 520 : 250} r={90} fill={dawn ? '#ffb347' : '#ffe27a'} />
    <rect x={0} y={640} width={360} height={620} fill="#e9a8a0" {...o} />
    <rect x={360} y={720} width={360} height={540} fill="#9fc5a0" {...o} />
    <rect x={720} y={620} width={360} height={640} fill="#f2d28c" {...o} />
    {[0, 360, 720].map((x, i) => (
      <g key={x}>
        <path d={`M${x} ${i === 1 ? 830 : 800} H${x + 360} L${x + 340} ${i === 1 ? 890 : 860} H${x + 20}Z`} fill="url(#st)" {...o} />
        <rect x={x + 40} y={960} width={280} height={240} rx={10} fill="#fdf3da" {...o} />
      </g>
    ))}
    <rect x={60} y={670} width={240} height={80} rx={10} fill="#fff8e1" {...o} /><Txt x={180} y={728} size={46}>মুদি দোকান</Txt>
    <rect x={420} y={745} width={240} height={70} rx={10} fill="#fff8e1" {...o} /><Txt x={540} y={796} size={44}>ফল</Txt>
    <rect x={780} y={650} width={240} height={80} rx={10} fill="#fff8e1" {...o} /><Txt x={900} y={708} size={46}>ওষুধ</Txt>
    <path d="M120 400 L240 400 M840 400 L960 400" stroke={INK} strokeWidth={4} />
    <rect x={240} y={370} width={600} height={110} rx={16} fill="#ff7b54" {...o} /><Txt x={540} y={452} size={78} fill="#fff">বাজার</Txt>
    <Ground />
  </Full>
);

export const Stall: React.FC<{x: number; y: number; s?: number; layer: 'back' | 'front'; kettle?: boolean}> = ({x, y, s = 1, layer, kettle}) => (
  <Full>
    <defs><Stripes /></defs>
    <g transform={`translate(${x} ${y}) scale(${s})`} stroke={INK} strokeWidth={3}>
      {layer === 'back' ? (
        <>
          <rect x={-200} y={-430} width={14} height={430} fill="#8d5a2b" /><rect x={186} y={-430} width={14} height={430} fill="#8d5a2b" />
          <path d="M-240 -430 H240 L205 -500 H-205Z" fill="url(#st)" />
          <rect x={-70} y={-420} width={140} height={64} rx={14} fill="#fff8e1" /><Txt x={0} y={-370} size={52}>চা</Txt>
        </>
      ) : (
        <>
          <rect x={-210} y={-190} width={420} height={190} fill="#b7793f" />
          <rect x={-222} y={-214} width={444} height={28} rx={8} fill="#d49a5b" />
          {kettle && (
            <g transform="translate(110 -214)">
              <path d="M-26 0 Q-26 -30 0 -30 Q26 -30 26 0Z" fill="#c9d1d9" /><path d="M-26 -8 L-44 -26 L-34 -30 L-24 -18Z" fill="#b8c0c8" />
              <path d="M-14 -30 Q0 -52 14 -30" fill="none" />
            </g>
          )}
        </>
      )}
    </g>
  </Full>
);

export const ChairSvg: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1.2}) => (
  <Full>
    <g transform={`translate(${x} ${y}) scale(${s})`} {...o} fill="#b7793f">
      <rect x={-40} y={-172} width={10} height={94} /><rect x={30} y={-172} width={10} height={94} />
      <rect x={-44} y={-176} width={88} height={12} rx={5} />
      <rect x={-36} y={-72} width={10} height={72} /><rect x={26} y={-72} width={10} height={72} />
      <rect x={-48} y={-84} width={96} height={16} rx={6} fill="#d49a5b" />
    </g>
  </Full>
);

export const RoomBG: React.FC = () => (
  <Full>
    <rect width={W} height={H} fill="#f4e4c8" />
    <rect y={1236} width={W} height={H - 1236} fill="#b98b5e" /><rect y={1226} width={W} height={16} fill="#8f6639" />
    <rect x={70} y={420} width={330} height={420} fill="#bfe3f7" stroke={INK} strokeWidth={8} />
    <path d="M235 420 V840 M70 630 H400" stroke={INK} strokeWidth={6} />
    <rect x={640} y={700} width={340} height={550} fill="#8d5a2b" {...o} />
    <rect x={652} y={712} width={158} height={526} fill="#a56d38" {...o} /><rect x={812} y={712} width={156} height={526} fill="#a56d38" {...o} />
    <circle cx={790} cy={980} r={9} fill="#e9c46a" {...o} /><circle cx={832} cy={980} r={9} fill="#e9c46a" {...o} />
  </Full>
);

export const PlainBG: React.FC<{c1?: string; c2?: string}> = ({c1 = '#fff7e6', c2 = '#f3d9b1'}) => (
  <Full>
    <defs><radialGradient id="rg" cx="50%" cy="45%" r="75%"><stop offset="0" stopColor={c1} /><stop offset="1" stopColor={c2} /></radialGradient></defs>
    <rect width={W} height={H} fill="url(#rg)" />
  </Full>
);

// ক্যাফের সামনের দৃশ্য; table/door/board = ০–১ পপ-অগ্রগতি
export const CafeBG: React.FC<{table?: number; door?: number; board?: number}> = ({table = 1, door = 1, board = 1}) => (
  <Full>
    <defs><linearGradient id="sk2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#bfe3f7" /><stop offset="1" stopColor="#f3fbff" /></linearGradient></defs>
    <rect width={W} height={H} fill="url(#sk2)" />
    <rect x={40} y={560} width={1000} height={700} fill="#f0dcc0" {...o} />
    <rect x={20} y={520} width={1040} height={60} rx={8} fill="#c26b4a" {...o} />
    <rect x={400} y={720} width={280} height={540} fill="#3a2b24" {...o} />
    <rect x={90} y={780} width={250} height={320} rx={10} fill="#e8f6fb" stroke={INK} strokeWidth={8} /><path d="M215 780 V1100" stroke={INK} strokeWidth={5} />
    <rect x={740} y={780} width={250} height={320} rx={10} fill="#e8f6fb" stroke={INK} strokeWidth={8} /><path d="M865 780 V1100" stroke={INK} strokeWidth={5} />
    <Ground />
    {door > 0.02 && (
      <g transform={`translate(540 1260) scale(${door})`}>
        <rect x={-140} y={-540} width={280} height={540} fill="#d9f1fa" stroke={INK} strokeWidth={9} />
        <path d="M0 -540 V0 M-140 -270 H140" stroke={INK} strokeWidth={5} /><circle cx={-22} cy={-250} r={9} fill="#e9c46a" {...o} />
      </g>
    )}
    {board > 0.02 && (
      <g transform={`translate(540 650) scale(${board})`}>
        <rect x={-320} y={-62} width={640} height={124} rx={18} fill="#8d5a2b" {...o} /><Txt x={0} y={26} size={74} fill="#fff8e1">চা ও ক্যাফে</Txt>
      </g>
    )}
    {table > 0.02 && (
      <g transform={`translate(230 1300) scale(${table})`} {...o}>
        <rect x={-8} y={-120} width={16} height={120} fill="#8d5a2b" /><ellipse cx={0} cy={-124} rx={92} ry={20} fill="#d49a5b" />
        <path d="M-18 -140 Q-24 -156 -16 -166 M0 -140 Q-6 -156 2 -166" fill="none" stroke="#9aa5b1" strokeWidth={4} /><rect x={-26} y={-146} width={34} height={22} rx={6} fill="#fff" />
      </g>
    )}
  </Full>
);
