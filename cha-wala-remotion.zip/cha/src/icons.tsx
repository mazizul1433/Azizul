import React from 'react';
import {INK} from './theme';
const S = {stroke: INK, strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
type P = {s?: number};

export const Cup: React.FC<P> = ({s = 140}) => (
  <svg width={s} height={s} viewBox="0 0 100 100">
    <path d="M34 30 Q28 20 35 12 M50 30 Q44 18 51 8 M66 30 Q60 20 67 12" fill="none" stroke="#9aa5b1" strokeWidth={4} strokeLinecap="round" />
    <path d="M20 42 H78 V60 Q78 84 49 84 Q20 84 20 60Z" fill="#fff" {...S} />
    <rect x={22} y={46} width={54} height={8} fill="#c0763a" />
    <path d="M78 48 Q96 48 94 62 Q92 74 76 72" fill="none" {...S} />
    <ellipse cx={49} cy={90} rx={34} ry={5} fill="#e9c46a" {...S} />
  </svg>
);
export const Soap: React.FC<P> = ({s = 170}) => (
  <div style={{position: 'relative', width: s, height: s}}>
    <Cup s={s} />
    <svg width={s} height={s} viewBox="0 0 100 100" style={{position: 'absolute', left: 0, top: 0}}>
      {[[20, 28, 10], [80, 22, 8], [52, 6, 6], [90, 50, 5]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill="rgba(170,220,255,.75)" stroke={INK} strokeWidth={2.5} />)}
    </svg>
  </div>
);
export const Kettle: React.FC<P> = ({s = 160}) => (
  <svg width={s} height={s} viewBox="0 0 100 100">
    <path d="M30 42 Q10 40 8 22 L20 26 Q22 36 36 38Z" fill="#b8c0c8" {...S} />
    <path d="M26 46 Q26 30 52 30 Q78 30 78 46 L82 80 Q82 90 52 90 Q22 90 22 80Z" fill="#c9d1d9" {...S} />
    <path d="M34 30 Q52 6 72 30" fill="none" {...S} />
    <ellipse cx={52} cy={28} rx={14} ry={5} fill="#9aa5b1" {...S} />
  </svg>
);
export const Sun: React.FC<P & {rot?: number}> = ({s = 220, rot = 0}) => (
  <svg width={s} height={s} viewBox="-60 -60 120 120">
    <g transform={`rotate(${rot})`}>{Array.from({length: 12}, (_, i) => <line key={i} x1={0} y1={-40} x2={0} y2={-54} stroke="#ff9f1c" strokeWidth={7} strokeLinecap="round" transform={`rotate(${i * 30})`} />)}</g>
    <circle r={34} fill="#ffd23f" {...S} />
  </svg>
);
export const Heart: React.FC<P> = ({s = 90}) => (
  <svg width={s} height={s} viewBox="0 0 100 100"><path d="M50 85 C10 55 12 22 34 22 C44 22 50 30 50 36 C50 30 56 22 66 22 C88 22 90 55 50 85Z" fill="#ff5d73" {...S} /></svg>
);
export const Cert: React.FC<P> = ({s = 240}) => (
  <svg width={s} height={s * 0.8} viewBox="0 0 100 80">
    <rect x={6} y={6} width={88} height={68} rx={5} fill="#fffdf2" {...S} />
    <text x={50} y={36} textAnchor="middle" fontSize={20} fontWeight={700} fill={INK} fontFamily="sans-serif">M.A.</text>
    <path d="M22 46 H78 M22 56 H62" stroke="#aaa" strokeWidth={3} />
    <circle cx={76} cy={62} r={8} fill="#d9534f" {...S} />
  </svg>
);
export const Check: React.FC<P> = ({s = 80}) => (
  <svg width={s} height={s} viewBox="0 0 100 100"><circle cx={50} cy={50} r={42} fill="#2ecc71" {...S} /><path d="M28 52 L45 68 L74 34" fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" /></svg>
);
export const Milk: React.FC<P> = ({s = 170}) => (
  <svg width={s} height={s} viewBox="0 0 100 100">
    <path d="M38 14 H62 V28 Q72 36 72 50 V84 Q72 92 64 92 H36 Q28 92 28 84 V50 Q28 36 38 28Z" fill="#fff" {...S} />
    <rect x={29} y={52} width={42} height={26} fill="#6ec6ff" /><rect x={36} y={8} width={28} height={10} rx={3} fill="#e63946" {...S} />
  </svg>
);
export const Mortar: React.FC<P> = ({s = 170}) => (
  <svg width={s} height={s} viewBox="0 0 100 100">
    <path d="M30 52 Q40 30 52 42 Q60 26 70 38 Q76 48 68 54Z" fill="#e0b27a" {...S} />
    <line x1={64} y1={20} x2={50} y2={58} stroke="#8d5a2b" strokeWidth={9} strokeLinecap="round" />
    <path d="M14 52 H86 Q86 90 50 90 Q14 90 14 52Z" fill="#a9a29a" {...S} />
  </svg>
);
export const FrameIc: React.FC<P> = ({s = 440}) => (
  <svg width={s} height={s * 1.1} viewBox="0 0 100 110">
    <path d="M50 8 L16 30 M50 8 L84 30" stroke={INK} strokeWidth={2.5} fill="none" /><circle cx={50} cy={6} r={4} fill="#888" stroke={INK} strokeWidth={2} />
    <rect x={8} y={28} width={84} height={76} rx={4} fill="#8d5a2b" {...S} />
    <rect x={18} y={38} width={64} height={56} fill="#fffdf2" stroke={INK} strokeWidth={2.5} />
    <path d="M28 54 H72 M28 64 H72 M28 74 H58" stroke="#999" strokeWidth={3} /><circle cx={66} cy={82} r={7} fill="#d9534f" />
  </svg>
);
export const Eye: React.FC<P & {h?: number}> = ({s = 420, h = 1}) => (
  <svg width={s} height={s * 0.6} viewBox="0 0 100 60">
    <g transform={`translate(0 30) scale(1 ${h}) translate(0 -30)`}>
      <path d="M4 30 Q50 -6 96 30 Q50 66 4 30Z" fill="#fff" {...S} />
      <circle cx={50} cy={30} r={18} fill="#5b3a29" /><circle cx={50} cy={30} r={8} fill="#111" /><circle cx={56} cy={24} r={4} fill="#fff" />
    </g>
  </svg>
);
export const Person: React.FC<P> = ({s = 80}) => (
  <svg width={s * 0.75} height={s} viewBox="0 0 60 80"><circle cx={30} cy={20} r={14} fill="#c8a07a" {...S} strokeWidth={3} /><path d="M6 76 Q6 40 30 40 Q54 40 54 76Z" fill="#3a86ff" {...S} strokeWidth={3} /></svg>
);
export const Bus: React.FC = () => (
  <svg width={420} height={230} viewBox="0 0 420 230">
    <rect x={6} y={20} width={408} height={170} rx={26} fill="#ffc83d" {...S} />
    {[30, 120, 210, 300].map(x => <rect key={x} x={x} y={44} width={74} height={60} rx={10} fill="#bfe6f5" {...S} />)}
    <rect x={8} y={130} width={404} height={14} fill="#e63946" />
    <circle cx={96} cy={196} r={30} fill="#333" {...S} /><circle cx={324} cy={196} r={30} fill="#333" {...S} />
  </svg>
);
// ক্ষয়ে যাওয়া জুতার ক্লোজ-আপ; poly = পলিথিন গোঁজার অগ্রগতি (০–১)
export const ShoeClose: React.FC<{poly: number}> = ({poly}) => (
  <svg width={760} height={520} viewBox="0 0 380 260">
    <path d="M30 170 Q40 90 120 80 L210 84 Q290 100 350 170 L350 200 Q190 214 30 200Z" fill="#6b4a3a" {...S} />
    <path d="M120 80 Q150 120 210 84" fill="none" {...S} /><path d="M140 100 H170 M160 112 H190" stroke="#e8d9c0" strokeWidth={5} />
    <path d="M30 200 Q190 218 350 200 L346 228 Q190 248 34 228Z" fill="#3b2a22" {...S} />
    <ellipse cx={190} cy={229} rx={58} ry={9} fill="#f4e3c3" {...S} />
    <g transform={`translate(0 ${(1 - poly) * -70})`} opacity={poly}>
      <path d="M142 214 Q190 204 238 214 L234 238 Q190 246 146 238Z" fill="rgba(160,215,245,.8)" {...S} strokeWidth={3} />
      <path d="M160 220 L214 232" stroke="#fff" strokeWidth={3} />
    </g>
  </svg>
);
