import React, {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';
import {FPS, INK, FONT, clamp, eob} from './theme';
import {CAPS} from './captions';
import {HIDE} from './timeline';

const TCtx = createContext(0);
export const TProvider = TCtx.Provider;
export const useT = () => {const f = useCurrentFrame(); return useContext(TCtx) + f / FPS;};
export const win = (t: number, a: number, b: number) => t >= a && t < b;
export const lerp = (t: number, a: number, b: number, v0: number, v1: number) => v0 + (v1 - v0) * clamp((t - a) / (b - a));

type Ch = {children?: React.ReactNode};

// পপ-আপ এলিমেন্ট (কেন্দ্র x,y)
export const Pop: React.FC<Ch & {a: number; b?: number; x: number; y: number; float?: boolean; rot?: number}> = ({a, b = 1e9, x, y, float = true, rot = 0, children}) => {
  const t = useT();
  if (t < a || t > b + 0.3) return null;
  const k = eob((t - a) / 0.4), o = clamp((t - a) / 0.15) * (b < 1e8 ? 1 - clamp((t - b) / 0.25) : 1);
  const fy = float ? Math.sin(t * 3) * 8 : 0;
  return <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) translateY(${fy}px) scale(${k}) rotate(${rot}deg)`, opacity: o}}>{children}</div>;
};

// পুরো লেয়ার পপ (স্টল, চেয়ার)
export const PopWrap: React.FC<Ch & {a: number; ox: number; oy: number}> = ({a, ox, oy, children}) => {
  const t = useT();
  if (t < a) return null;
  return <div style={{position: 'absolute', inset: 0, transformOrigin: `${ox}px ${oy}px`, transform: `scale(${eob((t - a) / 0.45)})`}}>{children}</div>;
};

// দৃশ্যের অংশ: আগেরটার ওপর ক্রসফেড
export const Seg: React.FC<Ch & {a: number; b: number}> = ({a, b, children}) => {
  const t = useT();
  if (t < a || t >= b + 0.25) return null;
  return <div style={{position: 'absolute', inset: 0, opacity: clamp((t - a) / 0.25)}}>{children}</div>;
};

export const Rise: React.FC<Ch & {a: number; x: number; y: number}> = ({a, x, y, children}) => {
  const t = useT(), k = (t - a) / 2.2;
  if (k < 0 || k > 1) return null;
  return <div style={{position: 'absolute', left: x + Math.sin(k * 8) * 20, top: y - k * 280, transform: 'translate(-50%,-50%)', opacity: 1 - k * k}}>{children}</div>;
};

// স্পিচ কলআউট বাবল: by = বাবলের নিচের কিনারার y, tx = লেজের x
export const Bubble: React.FC<{a: number; b: number; l: number; w: number; by: number; tx: number; text: string; size?: number; color?: string}> = ({a, b, l, w, by, tx, text, size = 54, color = '#fff'}) => {
  const t = useT();
  if (t < a || t > b + 0.3) return null;
  const k = eob((t - a) / 0.35), o = clamp((t - a) / 0.12) * (1 - clamp((t - b) / 0.25));
  return (
    <div style={{position: 'absolute', left: l, bottom: 1920 - by, width: w, transform: `scale(${k})`, transformOrigin: `${tx - l}px 100%`, opacity: o}}>
      <div style={{background: color, border: `6px solid ${INK}`, borderRadius: 48, padding: '26px 34px', fontFamily: FONT, fontWeight: 700, fontSize: size, lineHeight: 1.3, color: INK, textAlign: 'center', position: 'relative', boxShadow: '0 10px 0 rgba(0,0,0,.12)'}}>
        {text}
        <div style={{position: 'absolute', left: tx - l - 22, bottom: -24, width: 40, height: 40, background: color, borderRight: `6px solid ${INK}`, borderBottom: `6px solid ${INK}`, transform: 'rotate(45deg)'}} />
      </div>
    </div>
  );
};

export const Tag: React.FC<{text: string; color?: string; size?: number}> = ({text, color = '#ff6b6b', size = 44}) => (
  <div style={{fontFamily: FONT, fontWeight: 700, fontSize: size, color: '#fff', background: color, border: `4px solid ${INK}`, borderRadius: 60, padding: '8px 32px', whiteSpace: 'nowrap', boxShadow: '0 6px 0 rgba(0,0,0,.18)'}}>{text}</div>
);

export const Dots: React.FC = () => (
  <div style={{background: '#fff', border: `5px solid ${INK}`, borderRadius: 44, padding: '0 34px', fontFamily: FONT, fontWeight: 700, fontSize: 70, lineHeight: '64px', color: INK}}>• • •</div>
);

export const Stamp: React.FC<{text: string; color?: string; size?: number}> = ({text, color = '#d62828', size = 84}) => (
  <div style={{fontFamily: FONT, fontWeight: 700, fontSize: size, color, border: `10px solid ${color}`, borderRadius: 28, padding: '14px 44px', background: 'rgba(255,255,255,.9)', textAlign: 'center', lineHeight: 1.2, maxWidth: 900}}>{text}</div>
);

export const NoteCard: React.FC<Ch & {w?: number}> = ({w = 620, children}) => (
  <div style={{width: w, background: '#fff3a8', border: `5px solid ${INK}`, borderRadius: 22, padding: '38px 30px 26px', fontFamily: FONT, fontWeight: 700, fontSize: 56, color: INK, textAlign: 'center', position: 'relative', boxShadow: '0 12px 0 rgba(0,0,0,.15)'}}>
    <div style={{position: 'absolute', top: -18, left: '50%', width: 34, height: 34, marginLeft: -17, borderRadius: '50%', background: '#e63946', border: `4px solid ${INK}`}} />
    {children}
  </div>
);

const KEY = ['চা', 'চায়ের', 'ইন্টারভিউ', 'ইন্টারভিউর', 'এমএ', 'রেজাল্ট', 'জুতার', 'পলিথিন', 'ফাইল', 'ফাইলটা', 'দোকান', 'কেটলি', 'ক্যাফে', 'ক্যাফের', 'কাস্টমার', 'দশজন', 'সততা', 'পরিশ্রম', 'ছোট', 'ডিগ্রির', 'চোখাচোখি', 'দুধ', 'আদা', 'চাকরি', 'টেবিল', 'বোর্ড'];

// নিচের ভাসমান ক্যাপশন (ফুল-স্ক্রিন দৃশ্যের ওপর ওভারলে)
export const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  if (HIDE.some(([a, b]) => t >= a && t < b)) return null;
  const c = CAPS.find(([s, e]) => t >= s && t < e);
  if (!c) return null;
  const k = clamp((t - c[0]) / 0.2), fs = clamp(900 / (c[2].length * 0.52), 46, 66);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 250, textAlign: 'center', opacity: k, transform: `translateY(${(1 - k) * 30}px)`}}>
      <span style={{fontFamily: FONT, fontWeight: 700, fontSize: fs, color: '#fff', background: 'rgba(20,20,30,.74)', padding: '10px 36px', borderRadius: 40, whiteSpace: 'nowrap'}}>
        {c[2].split(' ').map((w, i) => (
          <span key={i} style={{color: KEY.includes(w.replace(/[।,?!]/g, '')) ? '#ffd23f' : '#fff'}}>{i ? ' ' : ''}{w}</span>
        ))}
      </span>
    </div>
  );
};
