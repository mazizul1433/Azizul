import {loadFont} from '@remotion/google-fonts/HindSiliguri';
export const {fontFamily: FONT} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});
export const W = 1080, H = 1920, FPS = 30, INK = '#222222';
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const eob = (x: number) => {const c = 1.70158, k = clamp(x); return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2);};
export const fr = (s: number) => Math.round(s * FPS);
