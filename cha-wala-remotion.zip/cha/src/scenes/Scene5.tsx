import React from 'react';
import {FPS, eob} from '../theme';
import {useT, win, lerp, Pop, Bubble, Tag} from '../ui';
import {Character, LOOKS, FileP, ApronP, UmbrellaP} from '../Character';
import {CafeBG} from '../bg';
import {DLG} from '../captions';

export const Scene5: React.FC = () => {
  const t = useT(), f = t * FPS, [a, b] = DLG[4], [c, d] = DLG[5];
  const tx = lerp(t, 106.2, 108.6, 1250, 640);
  const tArm = win(t, 122.9, 123.5) || win(t, 125.2, 126.1) ? 70 : 10;
  const rArm = win(t, 128.4, 130.2) ? 80 : win(t, 123.0, 125.6) ? 75 : 5;
  const rHold = win(t, 123.4, 125.4) ? <FileP /> : win(t, 128.4, 130.2) ? <ApronP /> : undefined;
  return (
    <>
      <CafeBG table={0} />
      {t >= 112.4 && <Character look={LOOKS.azhar} f={f} x={930} y={1190} scale={0.6 * eob((t - 112.4) / 0.4)} expr="sad" tilt={14} holdL={<UmbrellaP />} seed={9} />}
      <Character look={{...LOOKS.rakib, shoes: 'good'}} f={f} x={250} y={1300} scale={1.05} expr={t < 126 ? 'neutral' : 'happy'} talk={win(t, c, d)} armR={rArm} holdR={rHold} gaze={1} seed={1} />
      <Character look={LOOKS.tanvir} f={f} x={tx} y={1300} scale={1.05} expr={t < 127.6 ? 'worried' : 'happy'} walk={win(t, 106.2, 108.6)} talk={win(t, a, b)} tremble={win(t, 112, 122.5)} armL={win(t, 106.2, 108.6) ? undefined : tArm} holdL={win(t, 123.4, 125.4) ? undefined : <FileP />} gaze={-1} seed={2} />
      <Pop a={109.8} b={112.2} x={640} y={720} float={false}><Tag text="তানভীর" color="#8338ec" /></Pop>
      <Bubble a={a - 0.1} b={b + 0.3} l={330} w={700} by={690} tx={640} text="ভাইয়া, কোথাও চাকরি পাচ্ছি না। আপনার এখানে কি কোনো কাজ হবে?" color="#f1e8ff" />
      <Bubble a={c - 0.1} b={d + 0.3} l={40} w={780} by={690} tx={250} text="কাল সকাল আটটায় চলে এসো। এপ্রনটা আমি দিয়ে দেব।" color="#e6f7ee" />
    </>
  );
};
