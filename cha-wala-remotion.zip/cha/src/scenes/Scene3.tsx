import React from 'react';
import {FPS} from '../theme';
import {useT, win, lerp, Seg, Pop, Bubble, Tag, Dots} from '../ui';
import {Character, LOOKS, EXTRAS, CupP, UmbrellaP} from '../Character';
import {BazaarBG, Stall} from '../bg';
import {Cup, Soap} from '../icons';
import {DLG} from '../captions';

export const Scene3: React.FC = () => {
  const t = useT(), f = t * FPS, [a, b] = DLG[2], [c, d] = DLG[3];
  const ax = lerp(t, 49.6, 51.8, 1250, 830);
  const walking = win(t, 49.6, 51.8);
  const babaExpr = t < 46.4 ? 'neutral' : t < 58.4 ? 'worried' : t < c ? 'neutral' : 'happy';
  const azExpr = t < 51.8 ? 'neutral' : t < a ? 'smirk' : t < b + 0.3 ? 'angry' : 'worried';
  const cupHand = t < 61.3 || t >= 63.0;
  return (
    <>
      <BazaarBG />
      <Stall x={540} y={1100} s={0.7} layer="back" kettle />
      <Stall x={540} y={1100} s={0.7} layer="front" kettle />
      <Pop a={61.3} x={470} y={945} float={false}><Cup s={72} /></Pop>
      <Seg a={40.66} b={49.4}>
        <Character look={EXTRAS[2]} f={f} x={520} y={1300} scale={0.8} expr="smirk" gaze={-1} talk={win(t, 42, 45) || win(t, 46.6, 49)} seed={3} />
        <Character look={EXTRAS[3]} f={f} x={770} y={1300} scale={0.8} expr="smirk" gaze={-1} talk={win(t, 44.4, 46.5)} seed={4} />
        <Pop a={42} b={49.3} x={640} y={800}><Dots /></Pop>
      </Seg>
      <Character look={LOOKS.baba} f={f} x={230} y={1300} scale={1.05} expr={babaExpr} talk={win(t, c, d)} armR={t < 61.3 ? 55 : t < 63 ? 10 : 80} holdR={cupHand ? <CupP /> : undefined} seed={1} />
      {t >= 49.6 && <Character look={LOOKS.azhar} f={f} x={ax} y={1300} scale={1.05} expr={azExpr} walk={walking} talk={win(t, a, b)} tremble={win(t, a, b)} armL={walking ? undefined : 20} holdL={<UmbrellaP />} seed={2} />}
      <Pop a={43.3} b={45.5} x={230} y={720} float={false}><Tag text="বাবা" color="#2a9d8f" /></Pop>
      <Pop a={50.9} b={53.2} x={830} y={720} float={false}><Tag text="চাচা আজহার" color="#e76f51" /></Pop>
      <Pop a={56.2} b={58.4} x={540} y={850}><Soap s={190} /></Pop>
      <Bubble a={a - 0.1} b={b + 0.3} l={150} w={880} by={690} tx={830} text="এত টাকা খরচ করে ছেলেকে পড়ালেন, আর সে এখন কাপ ধুচ্ছে! এই লাভ হলো আপনার?" color="#ffe3e0" />
      <Bubble a={c - 0.1} b={d + 0.3} l={60} w={820} by={690} tx={230} text="কাপটা কিন্তু ভালোই ধুয়েছে। চা-টাও খেয়ে দেখুন, আরেক কাপ দেব?" color="#e6f7ee" />
    </>
  );
};
