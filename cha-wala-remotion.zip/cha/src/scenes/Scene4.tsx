import React from 'react';
import {FPS, eob} from '../theme';
import {useT, win, lerp, Seg, Pop, PopWrap, Tag, NoteCard, Stamp, Rise} from '../ui';
import {Character, LOOKS, EXTRAS, staff, CupP} from '../Character';
import {BazaarBG, CafeBG, Stall, ChairSvg} from '../bg';
import {Heart, Milk, Mortar, Kettle, Person} from '../icons';

const FRONT = [130, 330, 750, 950], BACK = [120, 300, 480, 660, 840, 1020];

export const Scene4: React.FC = () => {
  const t = useT(), f = t * FPS;
  const RK = {...LOOKS.rakib, shoes: 'good' as const};
  const tbl = eob((t - 94.3) / 0.5), door = eob((t - 95.8) / 0.5), brd = eob((t - 97.6) / 0.5);
  const crew = [...BACK.map(x => [x, 1170, 0.5]), ...FRONT.map(x => [x, 1300, 0.55])];
  return (
    <>
      {/* বাবা প্রথম চেয়ারে, কাস্টমার হাতে গোনা */}
      <Seg a={67.2} b={83.74}>
        <BazaarBG dawn />
        <Stall x={800} y={1130} s={0.85} layer="back" kettle />
        <Stall x={800} y={1130} s={0.85} layer="front" kettle />
        <ChairSvg x={330} y={1300} /><ChairSvg x={560} y={1300} />
        {win(t, 68, 77.5) && <Character look={EXTRAS[4]} f={f} x={lerp(t, 68, 77.5, 1250, -200)} y={1220} scale={0.8} walk seed={5} />}
        <Character look={LOOKS.baba} f={f} x={330} y={1300} scale={1.05} sit expr={t < 76.7 ? 'happy' : 'sad'} talk={win(t, 70.6, 76.5)} armL={t < 76.5 ? 120 + Math.sin(f / 4) * 28 : 5} armR={40} holdR={<CupP />} seed={1} />
        {win(t, 79.8, 84) && [0, 1].map(i => (
          <Character key={i} look={EXTRAS[2 + i]} f={f} x={lerp(t, 79.8, 84, 1250, -150) + i * 190} y={1190} scale={0.6} walk gaze={1} seed={i + 7} />
        ))}
        <Pop a={77.6} b={80.2} x={540} y={380} float={false}>
          <NoteCard w={640}>
            <div>কাস্টমার</div>
            <div style={{fontSize: 64, color: '#d62828'}}>হাতে গোনা</div>
            <div style={{display: 'flex', justifyContent: 'center', gap: 20, marginTop: 10}}><Person s={90} /><Person s={90} /><Person s={90} /></div>
          </NoteCard>
        </Pop>
      </Seg>
      {/* রাকিবের ভোরের প্রস্তুতি */}
      <Seg a={83.74} b={90.3}>
        <BazaarBG dawn />
        <Stall x={780} y={1130} s={0.85} layer="back" />
        <Stall x={780} y={1130} s={0.85} layer="front" />
        <Character look={RK} f={f} x={300} y={1300} scale={1.05} expr="determined" armR={win(t, 86.8, 88) ? 60 + Math.sin(f / 3) * 25 : 10} seed={1} />
        <Pop a={83.9} b={86} x={540} y={140}><Tag text="ভোর" color="#f4a261" /></Pop>
        <Pop a={85.4} b={88.2} x={150} y={620}><Milk s={190} /></Pop>
        <Pop a={86.7} b={88.4} x={400} y={520}><Mortar s={190} /></Pop>
        <Pop a={88.0} x={800} y={1010}><Kettle s={130} /></Pop>
      </Seg>
      {/* মুখে মুখে ছড়াল */}
      <Seg a={90.3} b={93.4}>
        <BazaarBG />
        <Stall x={780} y={1130} s={0.85} layer="back" kettle />
        <Stall x={780} y={1130} s={0.85} layer="front" kettle />
        <Character look={RK} f={f} x={300} y={1300} scale={1.05} expr="happy" armR={50} holdR={<CupP />} seed={1} />
        {[0, 1, 2, 3, 4].map(i => <Rise key={i} a={90.6 + i * 0.5} x={640 + (i % 3) * 90} y={900}><Heart s={90} /></Rise>)}
      </Seg>
      {/* টেবিল → কাচের দরজা → বোর্ড */}
      <Seg a={93.4} b={98.98}>
        <CafeBG table={t < 94.3 ? 0 : tbl} door={t < 95.8 ? 0 : door} board={t < 97.6 ? 0 : brd} />
        <Character look={RK} f={f} x={860} y={1300} scale={1.0} expr="happy" seed={2} />
      </Seg>
      {/* পুরোদস্তুর ক্যাফে, ১০ জন কর্মী */}
      <Seg a={98.98} b={106}>
        <CafeBG />
        {crew.map(([x, y, s], i) => {
          const a = 99.3 + i * 0.33;
          return t < a ? null : <Character key={i} look={staff(i)} f={f} x={x} y={y} scale={s * eob((t - a) / 0.35)} expr="happy" seed={i + 3} />;
        })}
        <Character look={RK} f={f} x={540} y={1340} scale={1.15} expr="proud" seed={1} />
        <Pop a={103.4} x={540} y={1530} float={false} rot={-4}><Stamp text="১০ জন" color="#2a9d57" size={110} /></Pop>
      </Seg>
    </>
  );
};
