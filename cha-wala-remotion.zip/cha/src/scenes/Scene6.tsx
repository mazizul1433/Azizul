import React from 'react';
import {FPS} from '../theme';
import {useT, lerp, Pop} from '../ui';
import {PlainBG} from '../bg';
import {Cup, Check, FrameIc, Eye} from '../icons';
import {FONT, INK} from '../theme';

const Row: React.FC<{show: boolean; text: string}> = ({show, text}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 24, justifyContent: 'center', opacity: show ? 1 : 0, fontSize: 92, marginBottom: 16}}>
    <Check s={90} /><span>{text}</span>
  </div>
);

export const Scene6: React.FC = () => {
  const t = useT(), f = t * FPS;
  return (
    <>
      <PlainBG />
      <Pop a={130.2} b={132.4} x={540} y={820} float={false}>
        <div style={{transform: `rotate(${Math.sin(f / 10) * 3}deg)`, transformOrigin: '50% 0'}}><FrameIc s={520} /></div>
      </Pop>
      <Pop a={132.4} b={134.5} x={540} y={820}><Cup s={420} /></Pop>
      <Pop a={134.6} b={139.4} x={540} y={800} float={false}>
        <div style={{width: 880, background: '#fff', border: `6px solid ${INK}`, borderRadius: 56, padding: '56px 40px', fontFamily: FONT, fontWeight: 700, color: INK, textAlign: 'center', boxShadow: '0 16px 0 rgba(0,0,0,.14)'}}>
          <Row show={t >= 135.2} text="সততা" />
          <Row show={t >= 135.8} text="পরিশ্রম" />
          <div style={{opacity: t >= 137.5 ? 1 : 0, fontSize: 84, color: '#2a9d57', marginTop: 24, lineHeight: 1.25}}>কোনো কাজই ছোট নয়</div>
        </div>
      </Pop>
      <Pop a={139.4} x={540} y={640} float={false}><Eye s={560} h={lerp(t, 140.6, 141.6, 0.38, 1)} /></Pop>
      <Pop a={139.6} x={540} y={1060}><Cup s={lerp(t, 139.6, 141.8, 120, 320)} /></Pop>
    </>
  );
};
