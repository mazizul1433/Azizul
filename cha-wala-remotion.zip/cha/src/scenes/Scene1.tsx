import React from 'react';
import {FPS} from '../theme';
import {useT, win, Pop, Bubble, Tag, Dots} from '../ui';
import {Character, LOOKS, EXTRAS} from '../Character';
import {BazaarBG, Stall} from '../bg';
import {DLG} from '../captions';

export const Scene1: React.FC = () => {
  const t = useT(), f = t * FPS, [a, b] = DLG[0];
  return (
    <>
      <BazaarBG />
      <Stall x={540} y={1080} s={0.62} layer="back" kettle />
      <Character look={LOOKS.rakib} f={f} x={540} y={1080} scale={0.5} expr={t < 8 ? 'neutral' : 'sad'} seed={1} />
      <Stall x={540} y={1080} s={0.62} layer="front" kettle />
      <Character look={EXTRAS[0]} f={f} x={230} y={1300} scale={1.1} expr="smirk" gaze={1} talk={win(t, a, b)} armR={t > b ? 70 : 30} seed={2} />
      <Character look={EXTRAS[1]} f={f} x={850} y={1300} scale={1.1} expr="smirk" gaze={-1} talk={win(t, b + 0.4, b + 3)} seed={3} />
      <Bubble a={a - 0.15} b={b + 0.35} l={40} w={780} by={660} tx={230} text="মাস্টার্স পাস করে শেষে চা বেচছে!" />
      <Pop a={0.2} b={3.4} x={540} y={140}><Tag text="বাজারের মোড় · সকাল" /></Pop>
      <Pop a={b + 0.6} b={10.2} x={850} y={640}><Dots /></Pop>
      <Pop a={7.0} b={10.2} x={540} y={770} float={false}><Tag text="রাকিব" color="#3a86ff" /></Pop>
    </>
  );
};
