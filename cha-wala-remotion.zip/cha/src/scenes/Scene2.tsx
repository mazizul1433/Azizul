import React from 'react';
import {FPS, eob, clamp} from '../theme';
import {useT, win, lerp, Seg, Pop, PopWrap, Tag, NoteCard, Stamp} from '../ui';
import {Character, LOOKS, FileP} from '../Character';
import {BazaarBG, PlainBG, RoomBG, Stall, ChairSvg} from '../bg';
import {Cert, Check, Sun, ShoeClose, Bus, Kettle} from '../icons';
import {DLG} from '../captions';

export const Scene2: React.FC = () => {
  const t = useT(), f = t * FPS, q = DLG[1][0];
  const R = {...LOOKS.rakib, apron: false};
  const cnt = Math.round(lerp(t, 14.9, 16.8, 0, 40));
  const sc = 1 + 2 * (1 - eob((t - q) / 0.25));
  const up = t < 33.3 ? lerp(t, 31.4, 33.0, 10, 165) : lerp(t, 33.3, 34.2, 165, 10);
  const bx = lerp(t, 17.3, 19.8, -300, 1380);
  return (
    <>
      {/* ১) এমএ পাস, ফাইল, ৪০+ ইন্টারভিউ */}
      <Seg a={10.22} b={21.5}><BazaarBG /></Seg>
      <Seg a={10.22} b={17.3}>
        <Character look={R} f={f} x={540} y={1300} scale={1.15} expr={t < 13.4 ? 'proud' : 'tired'} armR={25} holdR={t >= 13.4 ? <FileP /> : undefined} seed={1} />
        <Pop a={11.0} b={13.4} x={830} y={760}><Cert s={260} /></Pop>
        <Pop a={12.3} b={13.4} x={760} y={610}><Check s={90} /></Pop>
        <Pop a={14.85} b={17.3} x={540} y={400} float={false}>
          <NoteCard w={640}><div style={{fontSize: 120, lineHeight: 1}}>{cnt}+</div><div style={{fontSize: 56}}>ইন্টারভিউ</div></NoteCard>
        </Pop>
      </Seg>
      {/* ২) বাসে ঝোলা */}
      <Seg a={17.3} b={19.7}>
        <div style={{position: 'absolute', left: bx - 210, top: 1010}}><Bus /></div>
        <Character look={R} f={f} x={bx - 60} y={1250} scale={0.6} expr="tired" armR={170} tremble seed={2} />
      </Seg>
      {/* ৩) রোদে হাঁটা */}
      <Seg a={19.6} b={21.5}>
        <Pop a={19.7} x={860} y={320}><Sun s={260} rot={f * 2} /></Pop>
        <Character look={R} f={f} x={lerp(t, 19.6, 21.6, 160, 900)} y={1300} scale={1.1} walk expr="tired" holdR={<FileP />} seed={3} />
      </Seg>
      {/* ৪) জুতার ক্লোজ-আপ */}
      <Seg a={21.5} b={28.3}>
        <PlainBG c1="#fff4d6" c2="#f0d9a8" />
        <div style={{position: 'absolute', left: 160, top: 560, transform: `scale(${lerp(t, 21.5, 28.4, 0.85, 1.1)})`, transformOrigin: '380px 260px'}}>
          <ShoeClose poly={clamp((t - 25.4) / 1.4)} />
        </div>
      </Seg>
      {/* ৫) "আমরা আপনাকে পরে জানাব" স্ট্যাম্প */}
      <Seg a={28.3} b={31.4}>
        <PlainBG c1="#eef3fb" c2="#c7d4ea" />
        <Character look={R} f={f} x={540} y={1340} scale={1.1} expr="sad" holdR={<FileP />} armR={20} seed={4} />
        <div style={{position: 'absolute', left: 540, top: 560, transform: `translate(-50%,-50%) rotate(-7deg) scale(${sc})`, opacity: t < q ? 0 : 1}}>
          <Stamp text="আমরা আপনাকে পরে জানাব" />
        </div>
      </Seg>
      {/* ৬) ফাইল আলমারির মাথায় */}
      <Seg a={31.4} b={34.7}>
        <RoomBG />
        <Character look={R} f={f} x={560} y={1290} scale={1.15} expr={t < 33.3 ? 'tired' : 'determined'} armR={up} holdR={t < 33.3 ? <FileP /> : undefined} seed={5} />
        {t >= 33.3 && (
          <svg width={140} height={160} viewBox="-70 -80 140 160" style={{position: 'absolute', left: 610, top: 580}}><g transform="scale(1.5)"><FileP /></g></svg>
        )}
      </Seg>
      {/* ৭) চায়ের দোকান খোলা */}
      <Seg a={34.7} b={40.66}>
        <BazaarBG dawn />
        <PopWrap a={35.6} ox={780} oy={1250}>
          <Stall x={780} y={1250} s={0.9} layer="back" />
          <Stall x={780} y={1250} s={0.9} layer="front" />
        </PopWrap>
        <PopWrap a={39.1} ox={400} oy={1300}><ChairSvg x={400} y={1300} /></PopWrap>
        <PopWrap a={39.4} ox={540} oy={1300}><ChairSvg x={540} y={1300} /></PopWrap>
        <Pop a={38.1} x={800} y={1010}><Kettle s={120} /></Pop>
        <Character look={R} f={f} x={220} y={1300} scale={1.1} expr={t < 37.5 ? 'determined' : 'proud'} seed={6} />
        <Pop a={34.8} b={37.2} x={540} y={140}><Tag text="বাজারের কোণ" /></Pop>
      </Seg>
    </>
  );
};
