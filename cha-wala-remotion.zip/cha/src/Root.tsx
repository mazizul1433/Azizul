import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {TOTAL} from './timeline';
import {FPS, W, H} from './theme';

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
);
