import React from 'react';
import {INK} from './theme';

export type Look = {
  skin: string; hair?: string; bald?: boolean; shirt: string; pants?: string; long?: boolean;
  beard?: 'stubble' | 'white'; mustache?: string; glasses?: 'thick' | 'round'; topi?: boolean;
  apron?: boolean; lungi?: boolean; gamcha?: boolean; punjabi?: boolean; wrinkle?: boolean; shoes?: 'old' | 'good';
};
export type Expr = 'neutral' | 'happy' | 'sad' | 'angry' | 'surprised' | 'worried' | 'smirk' | 'proud' | 'tired' | 'determined';

export type CProps = {
  look: Look; f: number; x: number; y: number; scale?: number; flip?: boolean; expr?: Expr;
  talk?: boolean; walk?: boolean; sit?: boolean; tremble?: boolean;
  armL?: number; armR?: number; // ডিগ্রি: ০ = ঝুলে আছে, ৯০ = পাশে সোজা, ১৮০ = ওপরে
  holdL?: React.ReactNode; holdR?: React.ReactNode; gaze?: number; tilt?: number; seed?: number;
};

const BROW: Record<Expr, [number, number]> = {
  neutral: [0, 0], happy: [0, -3], sad: [-16, 0], worried: [-18, -2], angry: [20, 2],
  determined: [10, 2], surprised: [0, -14], tired: [-8, 2], smirk: [0, 0], proud: [0, -4],
};
const MOUTH: Record<Expr, string> = {
  neutral: 'M134 190 Q150 192 166 190', happy: 'M128 184 Q150 208 172 184', sad: 'M132 196 Q150 182 168 196',
  angry: 'M132 196 Q150 184 168 196', surprised: '', worried: 'M132 192 Q141 186 150 192 T168 192',
  smirk: 'M134 190 Q156 198 172 182', proud: 'M126 184 Q150 212 174 184', tired: 'M138 194 H162',
  determined: 'M134 190 Q150 196 166 186',
};

const Cap: React.FC<{x1: number; y1: number; x2: number; y2: number; w: number; c: string}> = ({x1, y1, x2, y2, w, c}) => (
  <g strokeLinecap="round">
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={w + 5} />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth={w} />
  </g>
);

export const Character: React.FC<CProps> = (p) => {
  const {look: L, f, x, y, scale = 1, flip, expr = 'neutral', talk, walk, sit, tremble, gaze = 0, tilt = 0, seed = 0} = p;
  const ph = f / 15 + seed;
  const bob = Math.sin(ph) * 4 - (walk ? Math.abs(Math.sin(f / 5)) * 12 : 0);
  const jx = tremble ? Math.sin(f * 2.7 + seed) * 3 : 0;
  const blink = ((f + seed * 37) % 110) < 4;
  const sw = walk ? Math.sin(f / 5) * 24 : 0;
  const aL = p.armL ?? (walk ? -sw : 3), aR = p.armR ?? (walk ? sw : 3);
  const n = Math.floor(f / 3) + Math.floor(seed * 3);
  const m = talk ? [2, 1, 0, 1, 2, 2, 1, 0][n % 8] : 0;
  const dy = sit ? 140 : 0, skin = L.skin, hair = L.hair || '#222', pants = L.pants || '#333';
  const sh = L.shoes === 'old' ? '#8a7766' : '#222';
  const sk = {stroke: INK, strokeWidth: 2.5, strokeLinejoin: 'round' as const};

  const leg = (cx: number, rot: number) => (
    <g key={cx} transform={`rotate(${rot} ${cx} 400)`}>
      {L.lungi ? <Cap x1={cx} y1={540} x2={cx} y2={584} w={26} c={skin} /> : <Cap x1={cx} y1={400} x2={cx} y2={580} w={38} c={pants} />}
      <ellipse cx={cx} cy={596} rx={29} ry={14} fill={L.lungi ? '#6b4a3a' : sh} {...sk} />
    </g>
  );
  const arm = (px: number, rot: number, hold: React.ReactNode, k: string) => (
    <g key={k} transform={`rotate(${rot} ${px} 240)`}>
      <Cap x1={px} y1={240} x2={px} y2={352} w={30} c={skin} />
      <Cap x1={px} y1={240} x2={px} y2={L.long ? 330 : 290} w={33} c={L.shirt} />
      <circle cx={px} cy={362} r={17} fill={skin} {...sk} />
      {hold ? <g transform={`translate(${px} 362) rotate(${-rot})`}>{hold}</g> : null}
    </g>
  );
  const [ba, bdy] = BROW[expr], by = 118 + bdy;
  const brow = (cx: number, a: number, ex = 0) => (
    <line x1={cx - 17} y1={by + ex} x2={cx + 17} y2={by + ex} stroke={INK} strokeWidth={6} strokeLinecap="round" transform={`rotate(${a} ${cx} ${by + ex})`} />
  );
  const eye = (cx: number) => blink ? (
    <path key={cx} d={`M${cx - 14} 146 Q${cx} 152 ${cx + 14} 146`} fill="none" stroke={INK} strokeWidth={3.5} />
  ) : (
    <g key={cx}>
      <ellipse cx={cx} cy={144} rx={15} ry={expr === 'surprised' ? 20 : 17} fill="#fff" {...sk} />
      <circle cx={cx + gaze * 5} cy={145} r={expr === 'surprised' ? 5 : 7} fill={INK} />
      {expr === 'tired' && <><rect x={cx - 16} y={124} width={32} height={20} fill={skin} /><line x1={cx - 15} y1={144} x2={cx + 15} y2={144} stroke={INK} strokeWidth={3} /></>}
    </g>
  );
  const mouth = m === 0
    ? (expr === 'surprised' ? <ellipse cx={150} cy={194} rx={10} ry={13} fill="#7a1f2b" {...sk} /> : <path d={MOUTH[expr]} fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />)
    : m === 1 ? <ellipse cx={150} cy={192} rx={13} ry={8} fill="#7a1f2b" {...sk} />
    : <g><ellipse cx={150} cy={195} rx={17} ry={15} fill="#7a1f2b" {...sk} /><ellipse cx={150} cy={205} rx={9} ry={5} fill="#e8737f" /></g>;
  const lb = sit ? 475 : 560;

  return (
    <svg viewBox="0 0 300 640" style={{position: 'absolute', left: x - 150 * scale, top: y - 620 * scale, width: 300 * scale, height: 640 * scale, overflow: 'visible', transform: flip ? 'scaleX(-1)' : undefined}}>
      <g transform={`translate(${jx} ${bob})`}>
        {/* পা */}
        {sit ? (
          <g>
            <rect x={96} y={545} width={108} height={46} rx={22} fill={L.lungi ? '#c0392b' : pants} {...sk} />
            {[118, 182].map(cx => <ellipse key={cx} cx={cx} cy={598} rx={29} ry={14} fill={L.lungi ? '#6b4a3a' : sh} {...sk} />)}
          </g>
        ) : <>{leg(126, sw)}{leg(174, -sw)}</>}
        <g transform={`translate(0 ${dy})`}>
          {L.lungi && (
            <g>
              <path d={`M94 400 H206 L214 ${lb} H86Z`} fill="#c0392b" {...sk} />
              {[118, 150, 182].map(cx => <path key={cx} d={`M${cx} 410 V${lb - 8}`} stroke="rgba(255,255,255,.35)" strokeWidth={3} />)}
              <path d={`M92 ${lb - 40} H208`} stroke="rgba(255,255,255,.35)" strokeWidth={3} />
            </g>
          )}
          {/* শরীর */}
          <rect x={92} y={222} width={116} height={L.punjabi ? (sit ? 210 : 250) : 190} rx={L.punjabi ? 34 : 44} fill={L.shirt} {...sk} />
          {L.punjabi ? <><path d="M150 226 V300" stroke={INK} strokeWidth={2.5} /><circle cx={150} cy={262} r={3.5} fill={INK} /></> : <path d="M136 224 L150 246 L164 224Z" fill="#fff" {...sk} />}
          {L.wrinkle && <path d="M110 300 l14 6 M170 330 l16 -6 M120 360 l18 4" stroke={INK} strokeWidth={2} opacity={0.45} />}
          {L.apron && (
            <g>
              <path d="M110 296 H190 V420 Q190 430 180 430 H120 Q110 430 110 420Z" fill="#8f979e" {...sk} />
              <path d="M120 232 Q150 270 180 232" fill="none" stroke={INK} strokeWidth={4} />
              <path d="M92 300 H110 M190 300 H208" stroke={INK} strokeWidth={4} />
            </g>
          )}
          {L.gamcha && (
            <g transform="rotate(8 98 232)">
              <rect x={78} y={226} width={34} height={82} rx={8} fill="#f1f1f1" {...sk} />
              <path d="M78 250 H112 M78 270 H112" stroke="#d9534f" strokeWidth={6} />
            </g>
          )}
          {/* হাত */}
          {arm(96, aL, p.holdL, 'l')}
          {arm(204, -aR, p.holdR, 'r')}
          {/* ঘাড় ও মাথা */}
          <rect x={136} y={204} width={28} height={30} fill={skin} {...sk} />
          <g transform={`rotate(${tilt} 150 230)`}>
            <circle cx={90} cy={152} r={12} fill={skin} {...sk} /><circle cx={210} cy={152} r={12} fill={skin} {...sk} />
            <ellipse cx={150} cy={150} rx={60} ry={66} fill={skin} {...sk} />
            <path d="M146 160 Q150 171 157 164" fill="none" stroke={INK} strokeWidth={3} strokeLinecap="round" />
            {L.beard && <path d="M91 160 Q92 238 150 244 Q208 238 209 160 Q205 200 180 206 Q150 214 120 206 Q95 200 91 160Z" fill={L.beard === 'white' ? '#f4f4f4' : 'rgba(34,34,34,.38)'} stroke={L.beard === 'white' ? INK : 'none'} strokeWidth={2.5} />}
            {L.topi ? (
              <g>
                <ellipse cx={93} cy={152} rx={7} ry={15} fill="#eee" {...sk} /><ellipse cx={207} cy={152} rx={7} ry={15} fill="#eee" {...sk} />
                <path d="M92 114 Q92 66 150 64 Q208 66 208 114 Q150 100 92 114Z" fill="#fff" {...sk} />
                <path d="M120 82 V102 M150 76 V100 M180 82 V102" stroke="#cfcfcf" strokeWidth={3} />
              </g>
            ) : L.bald ? (
              <g fill={hair} {...sk}><path d="M90 150 Q84 118 102 106 Q94 130 98 164Z" /><path d="M210 150 Q216 118 198 106 Q206 130 202 164Z" /></g>
            ) : <path d="M86 150 Q70 70 150 64 Q230 70 214 150 Q204 100 150 100 Q96 100 86 150Z" fill={hair} {...sk} />}
            {eye(128)}{eye(172)}
            {brow(128, ba)}{brow(172, -ba, expr === 'smirk' ? -9 : 0)}
            {mouth}
            {L.mustache && <path d="M116 178 Q134 164 150 174 Q166 164 184 178 Q168 190 150 182 Q132 190 116 178Z" fill={L.mustache} {...sk} />}
            {L.glasses === 'thick' && (
              <g fill="rgba(255,255,255,.2)" stroke={INK} strokeWidth={6} strokeLinecap="round">
                <rect x={103} y={124} width={46} height={40} rx={12} /><rect x={151} y={124} width={46} height={40} rx={12} />
                <path d="M103 138 L90 134 M197 138 L210 134" fill="none" />
              </g>
            )}
            {L.glasses === 'round' && (
              <g fill="rgba(255,255,255,.2)" stroke={INK} strokeWidth={3.5}>
                <circle cx={128} cy={144} r={22} /><circle cx={172} cy={144} r={22} /><path d="M150 144 H150" />
              </g>
            )}
          </g>
        </g>
      </g>
    </svg>
  );
};

// হাতে ধরা প্রপস (হাতের বিন্দুতে বসে)
const ps = {stroke: INK, strokeWidth: 2.5, strokeLinejoin: 'round' as const};
export const FileP: React.FC = () => (
  <g transform="translate(-6 -14) rotate(-8)">
    <rect x={-26} y={-34} width={52} height={68} rx={5} fill="#3f7fd6" {...ps} />
    <rect x={-26} y={-34} width={20} height={9} rx={3} fill="#2f64ad" {...ps} />
    <path d="M-14 -8 H14 M-14 4 H14 M-14 16 H6" stroke="#fff" strokeWidth={3} />
  </g>
);
export const CupP: React.FC = () => (
  <g transform="translate(0 -18)">
    <path d="M-16 -12 H16 V8 Q16 24 0 24 Q-16 24 -16 8Z" fill="#fff" {...ps} />
    <rect x={-14} y={-8} width={28} height={6} fill="#c0763a" />
    <path d="M16 -6 Q28 -6 26 4 Q24 12 14 12" fill="none" {...ps} />
    <path d="M-6 -18 Q-12 -28 -4 -36 M6 -18 Q0 -28 8 -36" fill="none" stroke="#9aa5b1" strokeWidth={3} strokeLinecap="round" />
  </g>
);
export const UmbrellaP: React.FC = () => (
  <g transform="rotate(10)">
    <line x1={0} y1={40} x2={0} y2={-110} stroke="#5a3a22" strokeWidth={7} strokeLinecap="round" />
    <path d="M-12 -40 Q0 -150 0 -150 Q12 -40 12 -40Z" fill="#4a4a8a" {...ps} />
    <path d="M-24 40 Q-24 56 -8 54" fill="none" stroke="#5a3a22" strokeWidth={7} strokeLinecap="round" />
  </g>
);
export const ApronP: React.FC = () => (
  <g transform="translate(0 -10)">
    <path d="M-22 -18 H22 L30 40 H-30Z" fill="#8f979e" {...ps} />
    <path d="M-12 -18 Q0 -38 12 -18" fill="none" {...ps} />
  </g>
);

export const LOOKS: Record<'rakib' | 'baba' | 'azhar' | 'tanvir', Look> = {
  rakib: {skin: '#b98a63', hair: '#1b1b1b', shirt: '#8ec5f2', pants: '#2b2b2b', long: true, beard: 'stubble', apron: true, shoes: 'old'},
  baba: {skin: '#c19a76', hair: '#eee', shirt: '#fafafa', long: true, punjabi: true, lungi: true, beard: 'white', mustache: '#eee', glasses: 'thick', topi: true, gamcha: true, shoes: 'good'},
  azhar: {skin: '#c8a07a', hair: '#2a2a2a', bald: true, shirt: '#a1673a', pants: '#8c8c8c', long: true, mustache: '#222', shoes: 'good'},
  tanvir: {skin: '#c69c78', hair: '#1b1b1b', shirt: '#fbfbf5', pants: '#2f3340', long: true, glasses: 'round', wrinkle: true, shoes: 'good'},
};
export const EXTRAS: Look[] = [
  {skin: '#d2a679', hair: '#222', shirt: '#e07a5f', pants: '#3d405b', long: true, beard: 'stubble'},
  {skin: '#b98a63', hair: '#333', shirt: '#81b29a', pants: '#444', mustache: '#222'},
  {skin: '#c8a07a', hair: '#1b1b1b', shirt: '#f2cc8f', pants: '#2b2d42', long: true, glasses: 'round'},
  {skin: '#d9b08c', hair: '#4a3728', shirt: '#9b5de5', pants: '#333'},
  {skin: '#a9754f', hair: '#111', shirt: '#f15bb5', pants: '#3a3a55', long: true},
  {skin: '#c69c78', hair: '#222', shirt: '#00bbf9', pants: '#2b2b2b', beard: 'stubble'},
];
export const staff = (i: number): Look => ({...EXTRAS[i % EXTRAS.length], apron: true, shoes: 'good'});
